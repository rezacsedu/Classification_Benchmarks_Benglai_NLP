<!DOCTYPE html>
<html style="height: 100%">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Protein-Protein Interaction Visualizer</title>
    <meta name="description" content="Protein-Protein Interaction Visualizer">
    <meta name="author" content="Maulik Kamdar">

    <meta name="keywords"
          content="Maulik R. Kamdar, Laleh Kazemzadeh, Linked Data, Visualization, Human-Computer, Interaction, Semantic, Web, Technology, Data, Information, Digital, Enterprise, Research, Insight, Center, Analytics, Galway"/>

    <!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css"/>
    <link rel="stylesheet" href="css/search.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/animations.css" type="text/css">
    <link rel="stylesheet" href="css/style_new.css" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.css" media="screen">
    <link rel="stylesheet" href="css/bootstrap-select.css" type="text/css">


    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/58feda53fa.css">
    <!-- <link href="css/font-awesome" rel="stylesheet" /> -->
    <!-- <script type="text/javascript" src="js/json2.js"></script>-->
    <script src="http://code.jquery.com/jquery-1.10.1.min.js" type="text/javascript"></script>
    <script src="http://code.jquery.com/ui/1.8.23/jquery-ui.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/libraries/sigma.min.js"></script>
    <script type="text/javascript" src="js/libraries/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/libraries/bootstrap-select.js"></script>
    <script type="text/javascript" src="js/libraries/typeahead.bundle.js"></script>
    <script type="text/javascript" src="js/libraries/d3.v3.min.js"></script>
    <script type="text/javascript" src="js/libraries/sigma.forceatlas2.js"></script>
    <script type="text/javascript" src="js/libraries/html2canvas.js"></script>

    <script src="https://use.fontawesome.com/6ca3943e1c.js"></script>

    <!-- non-library javascript containing utility functions -->
    <!--<script type="text/javascript" src="js/revealdUtils.js"></script>-->


</head>
<body style="height: 100%;">
<div id="pageContainer" style="min-height: 85%;">
    <div class="header-top dark">
        <div class="container" align="center">
            <div class="row">
                <div class="col-xs-6 col-sm-9 col-md-12">
                    <!-- header-top-first start -->
                    <!-- ================ -->
                    <div class="header-top-first clearfix" style="width: 1140px;">
                        <ul class="social-links circle medium clearfix hidden-xs">
                            <li class="facebook"><a target="_blank"
                                                    href="https://www.facebook.com/profile.php?id=1101403776"><i
                                            class="fa fa-facebook"></i></a></li>
                            <li class="twitter"><a target="_blank" href="https://twitter.com/asifkarim85"><i
                                            class="fa fa-twitter"></i></a></li>
                            <li class="linkedin"><a target="_blank" href="https://ie.linkedin.com/in/rezacsedu16052013"><i
                                            class="fa fa-linkedin"></i></a></li>
                            <li class="youtube"><a target="_blank" href="https://www.youtube.com/user/SuperAsifkarim"><i
                                            class="fa fa-youtube-play"></i></a></li>
                            <li class="github"><a target="_blank" href="https://github.com/rezacsedu"><i
                                            class="fa fa-github"></i></a></li>
                            <li class="googleplus"><a target="_blank"
                                                      href="https://plus.google.com/u/0/117640375862911745684"><i
                                            class="fa fa-google-plus"></i></a></li>
                        </ul>

                        <ul class="list-inline hidden-sm hidden-xs">
                            <li><i class="fa fa-map-marker pr-5 pl-10" align="center"></i> <strong>Md. Rezaul Karim, PhD
                                    Researcher, The Insight Centre for Data Analytics, NUI Galway, Ireland </strong>
                            </li>
                            <li><i class="fa fa-envelope-o pr-5 pl-10" align="center"></i> <strong>
                                    asif.karim.csedu@gmail.com </strong></li>
                        </ul>
                    </div>
                    <!-- header-top-first end -->
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-1"> </div>
            <div class="col-md-10">
                <header class="header  fixed    clearfix">
                    <nav>
                        <div class="container-fluid">
                            <div class="col-md-3" style="color:#777777">
                                <img class="img-responsive" src="img/icon.png" alt="Mountain View">
                            </div>
                            <div class="col-md-9">
                                <ul class="nav nav-pills">
                                    <li class="active"><a data-toggle="tab" href="#homeTab">Home</a></li>
                                    <li><a data-toggle="tab" href="#endpoint">Query Endpoint</a></li>
                                    <li><a data-toggle="tab" href="#examples">Query Examples</a></li>
                                    <li><a data-toggle="tab" href="#cityUs">Cite Us</a></li>
                                    <li><a data-toggle="tab" href="#contacts">Contact</a></li>
                                    <li><a data-toggle="tab" href="#stats">Statistics</a></li>
                                    <li><a data-toggle="tab" href="#download">Download</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </header>

                <div class="container-fluid" id="mainDiv">
                    <div class="tab-content">
                        <div id="homeTab" class="tab-pane fade in active">
                            <?php include('tabs/home.html'); ?>
                        </div>
                        <div id="endpoint" class="tab-pane fade">
                            <a href="http://vmlifescience01.insight-centre.org:8890/sparql">Query Endpoint</a>
                        </div>
                        <div id="examples" class="tab-pane fade">
                            <?php include('tabs/examples.html'); ?>
                        </div>
                        <div id="download" class="tab-pane fade">
                            Download
                        </div>
                        <div id="stats" class="tab-pane fade">
                            <?php include('tabs/stats.html'); ?>
                        </div>
                        <div id="cityUs" class="tab-pane fade">
                            <?php include('tabs/citeus.html'); ?>
                        </div>
                        <div id="contacts" class="tab-pane fade">
                            <?php include('tabs/contact.html'); ?>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-1"></div>
        </div>
    </div>


    <div class="splashScreenExplorer">
        <img src="img/loading-animation.gif">
        <h2 align="center">Simulating. One moment please…</h2>
    </div>


    <script type="text/javascript" src="js/searchTypeahead.js"></script>
    <script type="text/javascript" src="js/sigmaforce.js"></script>
    <script type="text/javascript" src="js/dropdownlist.js"></script>
    <script type="text/javascript" src="js/vizQueries.js"></script>

    <script>
        /*var data = [];


         function download_csv() {
         var csv = 'Name,Title\n';
         data.forEach(function(row) {
         csv += row + ',';
         csv += "\n";
         });

         // console.log(csv);
         var hiddenElement = document.createElement('a');
         hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
         hiddenElement.target = '_blank';
         hiddenElement.download = 'download.csv';
         hiddenElement.click();
         }*/

    </script>
</div>

<footer id="footer" class="clearfix dark">

    <!-- .footer start -->
    <!-- ================ -->
    <div class="footer">
        <div class="container-fluid">
            <div class="footer-inner">
                <div class="row">
                    <div class="col-md-12 ">
                        <div class="footer-content text-center padding-ver-clear">
                            <div class="row">
                                <div class="col-md-4">
                                </div>
                                <div class="col-md-1">
                                    <img class="img-responsive" src="img/footer1.png">
                                </div>
                                <div class="col-md-1">
                                    <img class="img-responsive" src="img/footer2.png">
                                </div>
                                <div class="col-md-1">
                                    <img class="img-responsive" src="img/footer3.jpg">
                                </div>
                                <div class="col-md-1">
                                    <img class="img-responsive" src="img/footer4.png">
                                </div>
                                <div class="col-md-4">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .footer end -->

</footer>
</body>

</html>
