<?php

function constructQuery($query, $url)
{
   $format = 'application/sparql-results+json';

   $searchUrl = $url . '?'
      .'query='.urlencode($query)
      .'&format='.urlencode($format);;

   return $searchUrl;
}


function request($url)
{
   if (!function_exists('curl_init')){
      die('CURL is not installed!');
   }
   $ch= curl_init();

   curl_setopt($ch,
      CURLOPT_URL,
      $url);

   curl_setopt($ch,
      CURLOPT_RETURNTRANSFER,
      true);

   $response = curl_exec($ch);

   curl_close($ch);

   return $response;
}

$type = $_GET['type'];
#$url = "http://appsrv01.deri.ie:8012/HPA_Full/query";

$url = "http://vmlifescience01.insight-centre.org:8890/sparql";
switch($type) {
	case "tissue" : $query = "PREFIX ns: <http://data.bioinfo.deri.ie/gene/>
                            PREFIX fn: <http://www.w3.org/2005/xpath-functions#>
                            SELECT DISTINCT ?tissue
                            WHERE {
                              ?data ns:tissue ?tissue.
                            } ORDER BY (fn:lower-case(str(?tissue)))";
					break;
	case "celltype" : $query = "PREFIX ns: <http://data.bioinfo.deri.ie/gene/>
                              PREFIX fn: <http://www.w3.org/2005/xpath-functions#>
                              SELECT DISTINCT ?celltype
                              WHERE {
                                ?tissueCell ns:cellType ?celltype.
                              } ORDER BY (fn:lower-case(str(?celltype)))";
					break;
	case "location" : $query = "PREFIX ns: <http://data.bioinfo.deri.ie/gene/>
                              PREFIX fn: <http://www.w3.org/2005/xpath-functions#>
                              SELECT DISTINCT ?location
                              WHERE {
                                ?data ns:location ?location.
                              } ORDER BY (fn:lower-case(str(?location)))";
					break;
}
#echo $query;

$requestURL = constructQuery($query, $url);
$responseArray = request($requestURL);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>SPARQL Proxy Executor</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>

<body><?php echo $responseArray; ?>
</body>
</html>
