executeDropdownSparql("tissue");
executeDropdownSparql("celltype");
executeDropdownSparql("location");
$('.selectpicker').selectpicker({
  //style: 'btn-info',
  size: 8
});

// Changes XML to JSON
function xmlToJson(xml) {

	// Create the return object
	var obj = {};

	if (xml.nodeType == 1) { // element
		// do attributes
		if (xml.attributes.length > 0) {
		obj["@attributes"] = {};
			for (var j = 0; j < xml.attributes.length; j++) {
				var attribute = xml.attributes.item(j);
				obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
			}
		}
	} else if (xml.nodeType == 3) { // text
		obj = xml.nodeValue;
	}

	// do children
	if (xml.hasChildNodes()) {
		for(var i = 0; i < xml.childNodes.length; i++) {
			var item = xml.childNodes.item(i);
			var nodeName = item.nodeName;
			if (typeof(obj[nodeName]) == "undefined") {
				obj[nodeName] = xmlToJson(item);
			} else {
				if (typeof(obj[nodeName].push) == "undefined") {
					var old = obj[nodeName];
					obj[nodeName] = [];
					obj[nodeName].push(old);
				}
				obj[nodeName].push(xmlToJson(item));
			}
		}
	}
	return obj;
};

function executeDropdownSparql(type){
	//$('.splashScreenExplorer').show();
	$.ajax({
		url: "dropdownRequest.php?type=" +type,
	    aync: true,
	    success: function (json) {
	    	var dataParts = json.split('<body>');
	    	var data = JSON.parse(dataParts[dataParts.length-1].split('</body>')[0]);
	    	switch(type) {
	    		case "tissue" : loadTissueDropdown(data.results.bindings); break;
	    		case "celltype" : loadCellTypeDropdown(data.results.bindings); break;
	    		case "location" : loadLocaitonDropdown(data.results.bindings); break;
	    	}
	    }
	});
}

function loadTissueDropdown(data) {
	var options = "<option value=''> -- Tissue drop-down -- </option>";
	for(i in data){
		options += "<option value='" + data[i].tissue.value + "'>" + data[i].tissue.value + "</option>";
	}
	$('#tissueSelect').html(options);
  $('.selectpicker').selectpicker('refresh');
}

function loadCellTypeDropdown(data) {
	var options = "<option value=''> -- Cell type drop-down -- </option>";
	for(i in data){
		options += "<option value='" + data[i].celltype.value + "'>" + data[i].celltype.value + "</option>";
	}
	$('#cellTypeSelect').html(options);
  $('.selectpicker').selectpicker('refresh');
}

function loadLocaitonDropdown(data) {
	var options = "<option value=''> -- Cellular localization drop-down -- </option>";
	for(i in data){
		options += "<option value='" + data[i].location.value + "'>" + data[i].location.value + "</option>";
	}
	$('#cellularLocalizationSelect').html(options);
  $('.selectpicker').selectpicker('refresh');
	//$('.splashScreenExplorer').hide();
}
