//executeVizSparqlQuery("backend6");

function executeVizSparqlQuery(type){
  $('.splashScreenExplorer').show();
	$.ajax({
		url: "vizQueryRequest.php?type=" +type,
	    aync: true,
	    success: function (json) {
	    	var dataParts = json.split('<body>');
	    	var data = JSON.parse(dataParts[dataParts.length-1].split('</body>')[0]);
	    	switch(type) {
	    		case "general1" : loadGeneral1Response(data.results.bindings); break;
          case "general2" : loadGeneral2Response(data.results.bindings); break;
          case "general3" : loadGeneral3Response(data.results.bindings); break;
          case "general4" : loadGeneral4Response(data.results.bindings); break;
          case "usercase1" : loadUsercase1Response(data.results.bindings); break;
          case "usercase2" : loadUsercase2Response(data.results.bindings); break;
          case "usercase3" : loadUsercase3Response(data.results.bindings); break;
          case "backend1" : loadBackend1Response(data.results.bindings); break;
          case "backend2" : loadBackend2Response(data.results.bindings); break;
          case "backend3" : loadBackend3Response(data.results.bindings); break;
          case "backend4" : loadBackend4Response(data.results.bindings); break;
          case "backend5" : loadBackend5Response(data.results.bindings); break;
          case "backend6" : loadBackend6Response(data.results.bindings); break;
	    	}
        $('.splashScreenExplorer').hide();
	    }
	});
}

function loadGeneral1Response(data) {
  var table = document.getElementById("general1");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
	for(i in data){
    var table = document.getElementById("general1");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].name.value;
    cell3.innerHTML = data[i].domain.value;
    cell4.innerHTML = data[i].interDomain.value;
    cell5.innerHTML = data[i].intername.value;
    cell6.innerHTML = data[i].interGene.value;
    cell7.innerHTML = data[i].Protein.value;
	}
  $('#general1').show();
  $('#general1close').show();
}

function loadGeneral2Response(data) {
  var table = document.getElementById("general2");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
	for(i in data){
    var table = document.getElementById("general2");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].gene.value;
    cell3.innerHTML = data[i].tissueCell.value;
    cell4.innerHTML = data[i].tissue.value;
    cell5.innerHTML = data[i].expressionPoint.value;
    cell6.innerHTML = data[i].cellType.value;
    cell7.innerHTML = data[i].expressionLevel.value;
	}
  $('#general2').show();
  $('#general2close').show();
}

function loadGeneral3Response(data) {
  var table = document.getElementById("general3");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("general3");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].gene.value;
    cell3.innerHTML = data[i].cellLine.value;
    cell4.innerHTML = data[i].level.value;
    cell5.innerHTML = data[i].tpm.value;
    cell6.innerHTML = data[i].type.value;
  }
  $('#general3').show();
  $('#general3close').show();
}

function loadGeneral4Response(data) {
  var table = document.getElementById("general4");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("general4");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].gene.value;
    cell3.innerHTML = data[i].cellExpression.value;
    cell4.innerHTML = data[i].location.value;
  }
  $('#general4').show();
  $('#general4close').show();
}

function loadUsercase1Response(data) {
  var table = document.getElementById("usercase1");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
	for(i in data){
    var table = document.getElementById("usercase1");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].requestedDomainName.value;
    cell3.innerHTML = data[i].interactingDomainName.value;
    cell4.innerHTML = data[i].interactingProteinName.value;
    cell5.innerHTML = data[i].validatedProtein.value;
    cell6.innerHTML = data[i].validatedProteinName.value;
    cell7.innerHTML = data[i].publication.value;
	}
  $('#usercase1').show();
  $('#usercase1close').show();
}

function loadUsercase2Response(data) {
  var table = document.getElementById("usercase2");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
	for(i in data){
    var table = document.getElementById("usercase2");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].desiredDomainName.value;
    cell3.innerHTML = data[i].interactingDomain.value;
    cell4.innerHTML = data[i].interactingDomainName.value;
    cell5.innerHTML = (data[i].validatedScore? data[i].validatedScore.value : '');
    cell6.innerHTML = (data[i].inferredScore?data[i].inferredScore.value:'');
	}
  $('#usercase2').show();
  $('#usercase2close').show();
}

function loadUsercase3Response(data) {
  var table = document.getElementById("usercase3");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("usercase3");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].proteinNameA.value;
    cell3.innerHTML = data[i].ideogramA.value;
    cell4.innerHTML = data[i].proteinNameB.value;
    cell5.innerHTML = data[i].ideogramB.value;
    cell6.innerHTML = data[i].inferredScore.value;
    cell7.innerHTML = data[i].interaction.value;
  }
  $('#usercase3').show();
  $('#usercase3close').show();
}

function loadBackend1Response(data) {
  var table = document.getElementById("backend1");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("backend1");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].biogridInt.value;
    cell3.innerHTML = data[i].geneTos.value;
    cell4.innerHTML = data[i].geneSym.value;
    cell5.innerHTML = data[i].pub.value;
    cell6.innerHTML = data[i].qual.value;
    cell7.innerHTML = data[i].score.value;
  }
  $('#backend1').show();
  $('#backend1close').show();
}

function loadBackend2Response(data) {
  var table = document.getElementById("backend2");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("backend2");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].corumInt.value;
    cell3.innerHTML = data[i].k.value;
    cell4.innerHTML = data[i].name.value;
    cell5.innerHTML = data[i].geneSym.value;
    cell6.innerHTML = data[i].pub.value;
    cell7.innerHTML = data[i].comment.value;
  }
  $('#backend2').show();
  $('#backend2close').show();
}

function loadBackend3Response(data) {
  var table = document.getElementById("backend3");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("backend3");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].it.value;
    cell3.innerHTML = data[i].name.value;
    cell4.innerHTML = data[i].pcc.value;
  }
  $('#backend3').show();
  $('#backend3close').show();
}

function loadBackend4Response(data) {
  var table = document.getElementById("backend4");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("backend4");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].name.value;
    cell3.innerHTML = data[i].domain.value;
    cell4.innerHTML = data[i].interDomain.value;
    cell5.innerHTML = data[i].intername.value;
    cell6.innerHTML = data[i].interGene.value;
    cell7.innerHTML = data[i].geneName.value;
  }
  $('#backend4').show();
  $('#backend4close').show();
}

function loadBackend5Response(data) {
  var table = document.getElementById("backend5");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("backend5");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].go.value;
    cell3.innerHTML = data[i].geneComp.value;
    cell4.innerHTML = data[i].name.value;
    cell5.innerHTML = data[i].namespace.value;
    cell6.innerHTML = data[i].description.value;
  }

  $('#backend5').show();
  $('#backend5close').show();
}

function loadBackend6Response(data) {
  var table = document.getElementById("backend6");
  var rowCount = table.rows.length;
  for (var i = 1; i < rowCount; i++) {
     table.deleteRow(1);
  }
  for(i in data){
    var table = document.getElementById("backend6");
    var row = table.insertRow(parseInt(i)+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    cell1.innerHTML = (parseInt(i)+1);
    cell2.innerHTML = data[i].geneComp.value;
  }

  $('#backend6').show();
  $('#backend6close').show();
}
